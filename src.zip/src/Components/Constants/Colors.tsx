const Colors = {
  primaryHeader: '#5e2121',
  primaryWhite: 'white',
  primaryBlack: 'black',
  primaryBackground : '#c0bebe',
  inputBackground : '#cca0a0'
};

export default Colors;
